<?php
    // $data = file_get_contents('php://input');
    // echo $data->'name';
    $obj = file_get_contents('php://input');
    $arr = json_decode($obj);
    echo $arr->{'name'};
?>