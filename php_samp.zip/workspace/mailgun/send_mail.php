<?php

# Include the Autoloader (see "Libraries" for install instructions)
require 'vendor/autoload.php';
use Mailgun\Mailgun;

# Instantiate the client.
$mgClient = new Mailgun('key-5ee013e440ecf17c3abd541800953d7e');
$domain = "sandbox8803d74da4e4483fbb96e40b34a32b07.mailgun.org";

$userData = file_get_contents('php://input');
$userData = json_decode($userData);

$msg = "from: " . $userData->{'email'} . "\n";
$msg .= "name: " . $userData->{'name'} . "\n";
$msg .= "comment: " . $userData->{'comment'};


# Make the call to the client.
$result = $mgClient->sendMessage("$domain",
          array('from'    => 'Mailgun Sandbox <postmaster@sandbox8803d74da4e4483fbb96e40b34a32b07.mailgun.org>',
                'to'      => 'omri <omrioei@gmail.com>',
                'subject' => 'Customer Issue',
                'text'    => $msg));

# You can see a record of this email in your logs: https://mailgun.com/app/logs .

# You can send up to 300 emails/day from this sandbox server.
# Next, you should add your own domain so you can send 10,000 emails/month for free.s

?>
