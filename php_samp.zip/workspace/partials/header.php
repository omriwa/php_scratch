<!DOCTYPE html>
<html>
    
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular-route.js"></script>
        <script type="text/javascript" src="../scripts/javascript/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="../scripts/javascript/tether.min.js"></script>
        <script type="text/javascript" src="../scripts/javascript/bootstrap.min.js"></script>
        <script type="text/javascript" src="../scripts/javascript/navbar.js"></script>
        <script type="text/javascript" src="../scripts/javascript/routing.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css" />
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/stylesheet.css" type="text/css" />
        <script type="text/javascript">
            window.onhashchange = function() { 
                $("#user-info").fadeOut(0,function(){});
            }
        </script>
    </head>
    
    <body ng-app="app" class="container-fluid">
        <div id="nav-div">   
            <nav class="navbar navbar-default navbar-static-top">
                
                    <ul>
                    
                        <li><a href="intro.php" active>Home</a></li>
                        <li><a href="#!about">About</a></li>
                        <li><a href="#!register">Register</a></li>
                        <li><a href="#!contact">Contact Us</a></li>
                        <li><a href="#!chat">Chat</a></li>
                        <li><a href="#!tic">tic tac toe</a></li>
                        <li><a href="#!sass">sass</a></li>
                    </ul>
     
            </nav>
        </div>
        
        <div id="user-info">
            
            <p id="user-msg"></p>
            
        </div>
        
        <div ng-view>
            
        </div>