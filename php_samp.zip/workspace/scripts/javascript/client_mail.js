angular.module('app').controller('clientMailCtl' ,['$scope','$http', function($scope , $http){
  
    $scope.getMailDataFromClient = function(){
        var data = {};
        data.name = $scope.name;
        data.email = $scope.email;
        data.comment = $scope.comment;
        return data;
    }
    
    $scope.showContactForm = function(){
      $("#user-msg").fadeToggle(1000 , function(){
        $("#user-info-menu").fadeToggle(0 , function(){
          $("#div-contact-form").fadeToggle(1000 , function(){});
        });
      });
    }
    
    $scope.announceUser = function(msg , color){
        $("#div-contact-form").fadeToggle(1000 , function(){
          $("#user-msg").text(msg);
          $("#user-msg").css("background-color" , color);
          $("#user-msg").fadeToggle(1000 , function(){
            $("#user-info-menu").fadeToggle(1000 , function(){});
          });
        })
    }
    
    $scope.getUserMinMenu = function(){
      var box = $("<div style=\"display:none;\" id=\"user-info-menu\"><div>") , btn = $("<button class=\"btn btn-lg btn-primary\">");
      btn.text("I want to send another message");
      btn.click($scope.showContactForm);
      box.append(btn)
      
      $("#user-info").append(box);
    }
    
    $scope.sendMail = function(){
        var data = $scope.getMailDataFromClient();
        data = JSON.stringify(data);
        console.log(data);
        $http.post("https://php-samp-omriwallach.c9users.io/mailgun//samp.php" , data)
        .then(
            function(res){
                $scope.announceUser("success" , "green");
            } ,
            function(){
                $scope.announceUser("failure" , "orange");
            });
        $scope.getUserMinMenu();
    }
}]);