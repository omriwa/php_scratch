//setup
$(document).ready(function(){
    disableRegularSubmit();
    //attach submit function to btn
    $("button").click(submit);
    
});

//validate form
function validateForm(){
    
}
//send ajax

function User(n , ln , mail , pass , g , com){
    var _name = n,
        _lastName = ln,
        _email = mail,
        _password = pass,
        _gender = g,
        _comment = com;
    
    //getters
    
    this.getName = function(){
        return _name;
    }
    
    this.getLastName = function(){
        return _lastName;
    }
    
    this.getEmail = function(){
        return _email;
    }
    
    this.getPassword = function(){
        return _password;
    }
    
    this.getGender = function(){
        return _gender;
    }
    
    this.comment = function(){
        return _comment;
    }
    //funcs
    this.isPassVal = function(){
        if(_password.length < 6)
            return false;
        else 
            return true;
    }
}



function disableRegularSubmit(){
    $("button").click(function(e){
        e.preventDefault();
    });
}  
function submit(){
    var user = initUser();
    //check if valid
    // if(user.isPassVal()){
        //waiting effect
        (function(){
            $("#register-box").fadeOut(2000 , alertReg);
        })();
    //send to server and check if valid
        post(user);
    
    // }

}

function post(user){
    $.post("../scripts/php/userRegistration.php" , user , function(){}).
    done(successfulReg.bind(user)).
    fail(faliureReg.bind(user));
}
/*handling successful registeration*/
function successfulReg(res){
    var siteRoot = "https://php-samp-omriwallach.c9users.io/view/";
    if(res === "true"){//user registered
        window.location.replace(siteRoot + "intro.php");
    }
    else{//announce that user exists
        console.log("reg failed the reason " + res);
    }
}
/*handling failure registration*/
function faliureReg(){
    alert("fail");
}

function alertReg(){
    var style = {
                    "z-index" : "1",
                    top : "25%",
                    opacity : "1"
                }
    $("#registration-info").css(style);
}

function initUser(){
    var name = $("input[name=name]").val(),
        lastName = $("input[name=lastName]").val(),
        email = $("input[name=email]").val(),
        password = $("input[name=password]").val(),
        gender = $("input[name=gender]").val(),
        comment = $("input[name=comment]").val();
        
    return new User(name,lastName,email,password,gender,comment);
}
