$(document).ready(function(){
            $(window).scroll(function(){
                var lastDiv;
                var contentDivs = $(".content");
                contentDivs.each(function(){
                    var scrollPos = $(window).scrollTop() + $(window).height() / 1.5;
                    var style = {
                                    opacity : "1"
                                };
                    if($(this).position(). top <= scrollPos){
                        $(this).animate(style , 1500 , function(){});
                        lastDiv = $(this);
                    }
                });
            });
});