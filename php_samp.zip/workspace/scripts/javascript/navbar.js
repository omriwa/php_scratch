$(document).ready(function(){
    $("nav").css("transition" , "none");
    navGUIEffect();
    $("nav").css("transition" , "all 1s");
});

function navGUIEffect(){
    $("#nav-div").mouseenter(function(event){
            $("nav").css("opacity" , "1");
    });
    
    $("#nav-div").mouseleave(function(event){
            $("nav").css("opacity" , "0");
    });
}