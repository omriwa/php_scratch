  angular.module('app').controller('regCtrl' , function($scope){
    $scope.firstName , $scope.lastName , $scope.mail , $scope.pass , $scope.commment,
    $scope.userMsg;
    
    $scope.submit = function(){//submit the form
      if(isValid()){
        
      }
    }
    //check validate
    function isValid(){
      //password check
      var bigC = false , smallC = false , num = false , length = false;
      if($scope.pass && $scope.pass.length < 20 && $scope.pass.length >= 3){//length check
        length = true;
        for(var i = 0 ; i < $scope.pass.length ; i++){
          if($scope.pass.charAt(i) <= 'Z' && $scope.pass.charAt(i) >= 'A')
            bigC = true;
          if($scope.pass.charAt(i) <= 'z' && $scope.pass.charAt(i) >= 'a')
            smallC = true;
          if($scope.pass.charAt(i) <= '9' && $scope.pass.charAt(i) >= '0')
            num = true;
          if(num && bigC && smallC){
            $scope.userMsg = "";
            return true;
          }
        }
      }
      
      setUserMsg(length , num , bigC , smallC);
      return false;
    }
    
    function setUserMsg(length , num , bigC , smallC){
      var msg = "";
      function addErr(otherMsg){
        if(msg.length > 0)
          msg += " " + otherMsg;
        else
          msg += otherMsg;
      }
      
      if(!length)
        addErr("length should be more");
      if(!num)
        addErr("should have at least 1 digit");
      if(!bigC)
        addErr("should have at least 1 big letter");
      if(!smallC)
        addErr("should have at least 1 smallC");
      $scope.userMsg = msg;
      console.log(msg);
    }
  });




