var app = angular.module("app", ["ngRoute"]);
  app.config(function($routeProvider , $locationProvider ) {    
    $routeProvider
    .when("/about" , {
      templateUrl : "./view/about.php"
    })
    .when("/register" ,  {
      templateUrl : "./view/register.php",
      controller : "regCtrl"
    })
    .when("/contact" , {
      templateUrl : "./view/contact.php",
      controller : "clientMailCtl"
    })
    .when("/chat" , {
      templateUrl : "./view/chat.php",
      controller : "chatCtl"
    })
    .when("/tic" , {
      templateUrl: "./view/tictactoe.php",
      controller: "gameCtl"
    })
    .when("/sass" , {
      templateUrl: "./view/sass.php"
    });
  });

///////////////////////controllers///////////////////////////////////
///registration controller

angular.module('app').controller('regCtrl' , function($scope){
    $scope.firstName , $scope.lastName , $scope.mail , $scope.pass , $scope.commment,
    $scope.userMsg;
    
    $scope.submit = function(){//submit the form
      if(isValid()){
        
      }
    }
    //check validate
    function isValid(){
      //password check
      var bigC = false , smallC = false , num = false , length = false;
      if($scope.pass && $scope.pass.length < 20 && $scope.pass.length >= 3){//length check
        length = true;
        for(var i = 0 ; i < $scope.pass.length ; i++){
          if($scope.pass.charAt(i) <= 'Z' && $scope.pass.charAt(i) >= 'A')
            bigC = true;
          if($scope.pass.charAt(i) <= 'z' && $scope.pass.charAt(i) >= 'a')
            smallC = true;
          if($scope.pass.charAt(i) <= '9' && $scope.pass.charAt(i) >= '0')
            num = true;
          if(num && bigC && smallC){
            $scope.userMsg = "";
            return true;
          }
        }
      }
      
      setUserMsg(length , num , bigC , smallC);
      return false;
    }
    
    function setUserMsg(length , num , bigC , smallC){
      var msg = "";
      function addErr(otherMsg){
        if(msg.length > 0)
          msg += " " + otherMsg;
        else
          msg += otherMsg;
      }
      
      if(!length)
        addErr("length should be more");
      if(!num)
        addErr("should have at least 1 digit");
      if(!bigC)
        addErr("should have at least 1 big letter");
      if(!smallC)
        addErr("should have at least 1 smallC");
      $scope.userMsg = msg;
      console.log(msg);
    }
  });





/////client mail controller
angular.module('app').controller('clientMailCtl' ,['$scope','$http', function($scope , $http){
    $scope.getMailDataFromClient = function(){
        var data = {};
        data.name = $scope.name;
        data.email = $scope.email;
        data.comment = $scope.comment;
        return data;
    }
    
    $scope.showContactForm = function(){
      $("#user-msg").fadeToggle(1000 , function(){
        $("#user-info-menu").fadeToggle(0 , function(){
          $("#div-contact-form").fadeToggle(1000 , function(){});
        });
      });
    }
    
    $scope.announceUser = function(msg , color){
        $("#div-contact-form").fadeToggle(1000 , function(){
          $("#user-msg").text(msg);
          $("#user-msg").css("background-color" , color);
          $("#user-msg").fadeToggle(1000 , function(){
            $("#user-info-menu").fadeToggle(1000 , function(){});
          });
        })
    }
    
    $scope.getUserMinMenu = function(){
      var box = $("<div style=\"display:none;\" id=\"user-info-menu\"><div>") , btn = $("<button class=\"btn btn-lg btn-primary\">");
      btn.text("I want to send another message");
      btn.click($scope.showContactForm);
      box.append(btn)
      
      $("#user-info").append(box);
    }
    
    $scope.sendMail = function(){
        var data = $scope.getMailDataFromClient();
        data = JSON.stringify(data);
        console.log(data);
        $http.post("https://php-samp-omriwallach.c9users.io/mailgun//samp.php" , data)
        .then(
            function(res){
                $scope.announceUser("success" , "green");
            } ,
            function(){
                $scope.announceUser("failure" , "orange");
            });
        $scope.getUserMinMenu();
    }
}]);

/////////////////chat controller

angular.module('app').controller('chatCtl',['$scope','$http', function($scope , $http){
    $scope.login = function(){
      $scope.loginFade();
    }
    
     //Send a Message
    $scope.sendMsg = function(){
        var msg = $scope.msg;
        $scope.msg = "";
    }
      
      
      
    $scope.loginFade = function(){
      $("#chat-login").fadeToggle(1000 , function(){
        var style = {
                      
                    };
        $(this).animate(style , 500 , function(){});
      });
    }
    
    $scope.loginFade();
}]);

///game controller
angular.module('app').controller('gameCtl',['$scope','$http', function($scope , $http){
 
  $scope.initGame = function(){
    $scope.gameBoard = [[,,,] , [,,,] , [,,,]];
    $scope.turn = $scope.sign;
    $scope.score = {user : 0 , pc : 0};
    pcMakeMove();
  }
  
  $scope.resetGame = function(){
  }
  
  $scope.putSign = function($event){
    if($scope.turn == 'x'){
      $event.target.textContent = 'X';
    }
    
    else{
      $event.target.textContent = 'O';
      $event.target.style.backgroundColor = 'green';
    }
    
    //change board logic
    setBoardLogic($event);
    //change sign
    changeSign();
    //send to server for pc move
    //update board logic
    //update gui
    //change sign
  }
  
  function changeSign() {
    if($scope.turn == 'x')
      $scope.turn = 'o';
    else
      $scope.turn = 'x';
  }
  
  function setBoardLogic($event){
    var cells = $('.game-cell');
    for(var row = 0 , col = 0 , i = 0 ; i < cells.length ; i++ ){
      col = i % 3;
      row = (Math.floor(i / 3)) % 3;
      if(cells[i] == $event.target)
        $scope.gameBoard[row , col] = $scope.turn;
    }
  }
  
  function pcMakeMove(){
    var data = {
                  sign : $scope.turn,
                  board : $scope.gameBoard
               };
    //convert to json
    data = JSON.stringify(data);
    $.post('https://php-samp-omriwallach.c9users.io/scripts/php/game_pc_logic.php',data , function(data){
      alert(data);
    });
  }
  
  
  
}]);







