<?php
    $userId = "userId";
    $userIdVal = $_POST["name"];
    if(!isset($_COOKIE[$userId])){//create a cookie for user
        setcookie($userId , $userIdVal , time() + (60) , "/");
    }
?>