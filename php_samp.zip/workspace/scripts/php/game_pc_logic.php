<?php

    $userData = file_get_contents('php://input');
    $userData = json_decode($userData);
    $node = new Node($userData);
    // $node = json_encode($node);
    $tree = new MiniMaxTree($node);
    
    echo json_encode($tree->getRoot()->getGameBoard());
    
    /*node class for representing each state of the game after each move*/
    class Node {
        
        private $gameBoard;
        private $huristicVal = 0;
        private $sign;
        private $father , $children = array();
    
        function Node($data){
            $this -> sign = $data -> {'sign'};
            $this -> gameBoard = $data -> {'board'};
        }
        
        function getGameBoard(){
            return $this -> gameBoard;
        }
            
        function setGameBoard($b){
            $this -> gameBoard = $b;
        }
        
        function getHuristicVal(){
            return $this -> huristicVal;
        }
        
        function setHuristicVal($v){
            $this -> huristicVal = $v;
        }
        
        function getFather(){
            return $this -> father;
        }
        
        function setFather($f){
            $this -> father = $f;
        }
        
        function getChildren(){
            return $this -> children;
        }
        
        function addChild($c){
            array_push($this -> children , $c);
        }
        
        function getSign(){
            return $this -> sign;
        }
        
        function setSign($s){
            $this -> sign = $s;
        }
        
    } 
    
    /*tree class representing all the states of the game and manipulations on the tree*/
    class MiniMaxTree{
        
        private $root;
        
        function miniMaxTree($r){
            $this -> root = $r;
            $this -> chooseMove($r , $r -> getSign());
        }
        
        function getRoot(){
            return $this -> root;
        }
        
        private function chooseMove($state , $sign){
            $board = $state -> getGameBoard();
            foreach($board as $row)
                foreach($row as $cell)
                    if(strlen($cell) == 0){
                        $row[$cell] = $sign;
                        break;
                    }
                    
        }
        
        
    }
    
    

?>