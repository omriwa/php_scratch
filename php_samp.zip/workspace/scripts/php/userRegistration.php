<?php 
    //Connect to the database
    $host = "127.0.0.1";
    $user = "omriwallach";                     //Your Cloud 9 username
    $pass = "";                                  //Remember, there is NO password by default!
    $db = "php_site";                                  //Your database name you want to connect to
    $port = 3306;                                //The port #. It is always 3306
    $connection = mysqli_connect($host, $user, $pass, $db, $port)or die(mysql_error());
    if(!$connection){
        //didnt connect to db
        echo "cant connect to db";
    }
    else{
        echo "true";
        //check if the user name is taken
        $query = "SELECT * FROM users";
        $res = mysql_query($query , $connection);
        if(!$res)
            echo "empty";
        // if(mysql_num_rows($res) != 0){
        //     echo "username exists choose another one";
        // }
        else{
            echo "bla";
        }
        // else{//check if the email is taken
        //     $query = "SELECT * FROM users WHERE user_name='" . $POST["email"] . "'";
        //     $res = mysql_query($query);
        //         if(mysql_num_rows($res) == 0){
        //         echo "username exists choose another one";
        //     }
        //     else{
        //         echo "true";
        //     }
        // }
    }
    if(!$connection)
        mysqli_close($connection);
?>