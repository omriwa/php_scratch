<div id="chat-login" style="display:none; z-index: 5;" class="form-group col-md-6 offset-md-3">
                    
    <label for="name">Nickname:</label>
    <input name="name" class="form-control" type="text" ng-model="name">
                    
    <button ng-click="login()" type="submit" style="margin: 2% 40%;" class="btn-success btn btn-lg">Login!</button>
                    
</div>
<div id="chat" style="opacity:0.3 ; z-index: -1;" class="container">
    
    <h3 style="text-align:center">Welcome to the chat</h3>
    
    <div id="chat-div" class="container row">
        
            <div id="users-text-box" class="col-md-9 row"><!--- users text -->
                
                <div id="mutual-chat" class="col-md-12">
                    
                    <textarea id="chat" style="height: 100%; width: 98%; resize : none ;" readonly></textarea>
                    
                </div>
                
                <div id="user-btn" class="col-md-12 container">
                    
                    <input type="text" name="msg" ng-model="msg"/>
                    <button ng-click="sendMsg()" class="btn btn-default">Send!</button>
                    
                </div>
                
            </div>
            
            <div id="users-list-box" class="col-md-3"><!--- users list -->
                
                
            </div>
        
    </div>
    
</div>
