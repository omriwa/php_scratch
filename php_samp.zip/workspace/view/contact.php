<div id="div-contact-form" class="container">
    <div class="row">
        
        <div style="margin: 1% auto">
            <h3>We Want to Hear from You!</h3>
        </div>
        
        <div class="col-md-12">
            <script type="text/javascript" src="../scripts/javascript/client_mail.js"></script>
            <form class="horizontal-from">
            
                <div class="form-group col-md-6 offset-md-3">
                    
                    <label for="name">Name:</label>
                    <input name="name" class="form-control" type="text" ng-model="name">
                    
                    <label for="mail">Mail:</label>
                    <input name="mail" class="form-control" type="mail" ng-model="email">
                    
                    <label for="comment">Comment:</label>
                    <textarea rows="10" cols="50" type="textarea" name="comment" class="form-control" ng-model="comment"></textarea>
                    
                    <button ng-click="sendMail()" type="submit" style="margin: 2% 40%;" class="btn-success btn btn-lg">Send!</button>
                    
                </div>
                
                
                
            </form>
            
        </div>
        
        
    </div>
    
    
</div>


