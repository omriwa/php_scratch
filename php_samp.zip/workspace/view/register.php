    <div id="registration-info">
        <p>Please wait , The registration proccess may take a while</p>
        <div id="process-circle"></div>
    </div>
        
    <div id="register-box">
        
        <h1>Register</h1>
        <p>{{userMsg}}</p>
        <form>
            <input class="text-input" type="text" name="name" placeholder="first name" ng-model="firstName"/>
            <input class="text-input" type="text" name="lastName" placeholder="last name" ng-model="lastName"/>
            <input class="text-input" type="email" name="email" placeholder="email" ng-model="email"/>
            <input class="text-input" type="password" name="password" placeholder="password" ng-model="pass"/>
            <p>Gender:</p>
            female<input type="radio" value="female" name="gender" ng-model="gender"/>
            male<input type="radio" value="male" name="gender" ng-model="gender"/>
            <textarea ng-model="comment.text"  class="text-input" name="comment" placeholder="Your Comment" rows="5" cols="20"></textarea>
            <button ng-click="submit()" id="registraion-btn" class="btn btn-md btn-primary">Submit</button>
        </form>
        
        <div>
            <h1>Dear {{firstName + " " + lastName}}</h1>
            <p>
                Info:
                <br>
                {{"your email: " + email}}
                <br>
                pass:
                {{pass}}
                <br>
                gender:
                {{gender}}
                <br>
                comment: 
                {{comment.text}}
            </p>
        </div>
         
    </div>
