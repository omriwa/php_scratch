    <h1>sass</h1>
    
    <div class="center-box">
        
       <form class="form-field">
           
           <label class="input-1 input-form-label" for="">input1</label>
           <input class="input-1" type="text" name=""/>
           <label class="input-2 input-form-label" for="">input2</label>
           <input class="input-2" type="text" name=""/>
           <label class="input-3 input-form-label" for="">input3</label>
           <input class="input-3" type="text" name=""/>
           <button class="form-btn">send!</button>
            
       </form>
        
    </div>
    
    <div class="info-div">
        
        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus luctus sit amet magna nec efficitur. In hac habitasse platea dictumst. Morbi gravida fringilla orci, sed tincidunt velit varius cursus. Phasellus nisl arcu, fringilla eget egestas sit amet, suscipit nec libero. Praesent tristique dictum tortor, in vulputate velit. Nulla consequat porta porttitor. Suspendisse rutrum lectus purus, eu convallis diam auctor id.

            Etiam lobortis hendrerit mi, nec sagittis mi euismod quis. Nullam scelerisque, nisl quis pharetra pharetra, magna nulla luctus purus, eu fermentum tellus nisl vitae quam. Aenean accumsan augue non facilisis convallis. Mauris ut velit a mauris pulvinar hendrerit. Nunc convallis tempus metus. Cras sodales orci quis rutrum lacinia. Aenean magna augue, fermentum ut felis vitae, commodo fermentum ipsum. Nunc sodales, lorem eu elementum interdum, augue ligula facilisis ipsum, in maximus mi tellus eu neque.

            Pellentesque sagittis magna quis tincidunt gravida. Donec pulvinar magna eget porttitor tristique. Nunc augue metus, consequat in nulla vitae, tristique tempus diam. Proin at ante condimentum, posuere nunc bibendum, consectetur mauris. Duis ut blandit nunc, et feugiat ipsum. Cras nulla ligula, rutrum quis risus quis, convallis ultrices augue. Etiam blandit posuere lectus, vitae suscipit orci feugiat eu. Fusce a massa urna. Etiam dapibus nulla lectus, eget tincidunt est condimentum non. Curabitur sit amet ex turpis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer ultrices auctor turpis, id condimentum lectus. Donec rutrum volutpat arcu. Fusce a diam augue.
        </p>
        
    </div>
    
    <div class="container-fluid div-shape">
        <div class="red-circle"></div>
        <div class="blue-circle"></div>
        <div class="green-circle"></div>
    </div>
    
    <link rel="stylesheet" href="../css/style.css" type="text/css" />