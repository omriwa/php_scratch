<div class="container">
    
    <h4 style="margin: 5% auto; text-align: center">tic tac toe</h4>
    
    <div style="margin: auto; text-align: center;">
        <h5>Scores</h5>
        <h6>pc: {{score.pc}}</h6>
        <h6>user: {{score.user}}</h6>
    
                <div>
                    <div class="game-cell" ng-click="putSign($event)"></div>
                    <div class="game-cell" ng-click="putSign($event)"></div>
                    <div class="game-cell" ng-click="putSign($event)"></div>  
                </div>
                
                <div>
                    <div class="game-cell" ng-click="putSign($event)"></div>
                    <div class="game-cell" ng-click="putSign($event)"></div>
                    <div class="game-cell" ng-click="putSign($event)"></div> 
                </div>
                
                <div>
                    <div class="game-cell" ng-click="putSign($event)"></div>
                    <div class="game-cell" ng-click="putSign($event)"></div>
                    <div class="game-cell" ng-click="putSign($event)"></div> 
                </div>
        
    </div>
    
    <div style="margin: auto; text-align: center;">
        
        <div>
            <label for="sign">Choose your sign</label>
            <select ng-model="sign">
                <option>x</option name="sign">
                <option>o</option name="sign">
            </select>
        </div>
        
        <div>
          <button ng-click="initGame()">Start!</button>
            <button ng-click="resetGame()">Reset!</button>  
        </div>
        
    </div>
    
</div>